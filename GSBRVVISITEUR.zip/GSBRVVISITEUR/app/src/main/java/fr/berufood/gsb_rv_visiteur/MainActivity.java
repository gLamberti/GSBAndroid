package fr.berufood.gsb_rv_visiteur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import fr.berufood.gsb_rv_visiteur.modeles.ModeleGsb;
import fr.berufood.gsb_rv_visiteur.technique.Session;

public class MainActivity extends AppCompatActivity {


    TextView tvError;
   // TextView prenomNom;
    String prenomNom;
    Button connect;
    Button annuler;

    Session session;
    EditText login;
    EditText pwd;

    String loginA ;
    String mdp ;

    protected  ModeleGsb modele = ModeleGsb.getInstance() ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (EditText)findViewById(R.id.etLogin);
        pwd = (EditText)findViewById(R.id.etPwd);


    }


    public void seConnecter(View vue) throws UnsupportedEncodingException {
        System.out.println("ca passe dans la méthode du bouton");

        loginA = login.getText().toString();
        mdp = pwd.getText().toString();
        Boolean estOuvert = session.ouvrir(loginA,mdp);

        //Récuperer sous forme de tableau/liste

        String idVisiteur = URLEncoder.encode(loginA, "UTF-8");
        String mdpVisiteur = URLEncoder.encode(mdp, "UTF-8");
        String url = String.format( "http://192.168.111.128:5000/connexion/%s/%s" , idVisiteur , mdpVisiteur );
        System.out.println(url);

        Response.Listener<JSONArray> ecouteurReponse = new Response.Listener<JSONArray>() {

            @Override
            public void onResponse(JSONArray response) {
                try {
                    System.out.println("ca passe dans lecouteur reponse");
                    for (int i =0 ; i < response.length(); i++){

                        Log.i("GSB", response.getJSONObject(i).getString("VIS_MATRICULE") + " " + response.getJSONObject(i).getString("VIS_MDP"));
                        String nomVisiteur = response.getJSONObject(i).getString("VIS_NOM") + " " + response.getJSONObject(i).getString("VIS_PRENOM");
                        String matVisiteur = response.getJSONObject(i).getString("VIS_MATRICULE");
                        System.out.println(matVisiteur);

                        Bundle paquet = new Bundle();
                        paquet.putString("nom", nomVisiteur);
                        paquet.putString("matricule", matVisiteur);
                        Intent intentionEnvoyer = new Intent(MainActivity.this, MenuActivity.class);
                        intentionEnvoyer.putExtras(paquet);
                        startActivity(intentionEnvoyer);

                    }
                }
                catch( JSONException e ){
                    Log.e("GSB", "Erreur JSON : " + e.getMessage());
                    System.out.println("Erreur JSON : ");
                }
            }
        };
        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("GSB", "Erreur HTTP : " + error.getMessage());
                System.out.println("ca passe dans ecouteur erreur");
            }
        };
        System.out.println("ca passe nul part");

        login.setText("");
        pwd.setText("");

        JsonArrayRequest requete = new JsonArrayRequest(Request.Method.GET, url , null, ecouteurReponse, ecouteurErreur);

        RequestQueue fileReq = Volley.newRequestQueue(this);
        fileReq.add(requete);



        //Récuperer sous forme de valeurs

        /*final String idVisiteur = URLEncoder.encode(loginA, "UTF-8");
        String mdpVisiteur = URLEncoder.encode(mdp, "UTF-8");
        String url = String.format( "http://192.168.111.128:5000/connexion/'%s'/'%s'" , idVisiteur , mdpVisiteur );
        System.out.println(url);

        Response.Listener<String> ecouteurReponse = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                System.out.println(response);


                Bundle paquet = new Bundle() ;
                paquet.putString("nom",idVisiteur);
                Intent intentionEnvoyer = new Intent(MainActivity.this,MenuActivity.class);
                intentionEnvoyer.putExtras(paquet);
                startActivity(intentionEnvoyer);

            }
        };

        System.out.println("ca passe dans lecouteur reponse");

        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("GSB" , "Erreur HTTP : " + error.getMessage());
                System.out.println("ca passe dans ecouteur erreur");

            }
        };
        StringRequest requete = new StringRequest(Request.Method.GET, url, ecouteurReponse,ecouteurErreur );
        RequestQueue fileReq = Volley.newRequestQueue(this);

        System.out.println("ca passe nul part");

        //Recuperer sous forme d'objet

        String idVisiteur = URLEncoder.encode(loginA, "UTF-8");
        String mdpVisiteur = URLEncoder.encode(mdp, "UTF-8");
        String url = String.format( "http://192.168.111.128:5000/connexion/%s/%s" , idVisiteur , mdpVisiteur );
        System.out.println(url);

        Response.Listener<JSONObject> ecouteurReponse = new Response.Listener<JSONObject>() {



            @Override
            public void onResponse(JSONObject response) {
                try {
                    System.out.println("ca passe dans lecouteur reponse");

                    String idVisiteur = response.getString("VIS_MATRICULE");
                    String nomVisiteur = response.getString("VIS_NOM");
                    String moisRV = response.getString("MONTH(RAP_DATE)");
                    String anneeRV = response.getString("YEAR(RAP_DATE");



                    Bundle paquet = new Bundle() ;
                    paquet.putString("nom",nomVisiteur);
                    Intent intentionEnvoyer = new Intent(MainActivity.this,MenuActivity.class);
                    intentionEnvoyer.putExtras(paquet);
                    startActivity(intentionEnvoyer);


                }
                catch( JSONException e ){
                    Log.e("GSB", "Erreur JSON : " + e.getMessage());
                    System.out.println("Erreur JSON : ");
                }
            }
        };
        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("GSB", "Erreur HTTP : " + error.getMessage());
                System.out.println("ca passe dans ecouteur erreur");
            }
        };
        System.out.println("ca passe nul part");


        JsonObjectRequest requete = new JsonObjectRequest(Request.Method.GET, url , null, ecouteurReponse, ecouteurErreur);

        RequestQueue fileReq = Volley.newRequestQueue(this);
        fileReq.add(requete);
        */












        //Récuperer d'après un modèle

       /* Visiteur leVisi = modele.seConnecter(loginA, mdp);
        if(leVisi != null) {

            Session.ouvrir(leVisi.getMatricule(), leVisi.getMdp());
            prenomNom = (leVisi.getNom() + " " + leVisi.getPrenom());
            String prenomNomVisiteur = (String) prenomNom.toString();

            Bundle paquet = new Bundle() ;
            paquet.putString("nom",prenomNomVisiteur);
            Intent intentionEnvoyer = new Intent(this, MenuActivity.class);
            intentionEnvoyer.putExtras(paquet);
            startActivity(intentionEnvoyer);

        }
        else {

            login.setText("");
            pwd.setText("");

            TextView tvError = (TextView) findViewById(R.id.tvError);
            tvError.setText("Echec de la connexion. Veuillez recommencer...");



        }*/

    }

    public void annuler(View vue) {


        login.setText("");
        pwd.setText("");

    }







}
