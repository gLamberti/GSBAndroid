package fr.berufood.gsb_rv_visiteur;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import fr.berufood.gsb_rv_visiteur.entites.RapportVisite;
import fr.berufood.gsb_rv_visiteur.modeles.ModeleGsb;
import fr.berufood.gsb_rv_visiteur.technique.Session;

//import fr.berufood.gsb_rv_visiteur.technique.ItemRVAdaptateur;



public class ListeRvActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    TextView tvRapport;
    //TextView tvMois;
    //TextView tvAnnee;
    ModeleGsb modele;
    ListView lvRapport;
    String nomVisiteur;
    Integer mois;
    Integer annee;
    String stringMois;
    String stringAnnee;
    String leRapport;
    String leRapportEntier;
    String leRapportFinal;
    List<String> lesRapportFinaux = new ArrayList<String>();
    List<String> lesRapportsJSON = new ArrayList<String>();
    List<String> lesRapportsDescJSON = new ArrayList<String>();


    Button btnValider ;





    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_rv);


        //tvMois = (TextView)findViewById(R.id.tvMois);
        //tvAnnee = (TextView)findViewById(R.id.tvAnnee);
        lvRapport = (ListView) findViewById(R.id.lvRapport);
        tvRapport = (TextView) findViewById(R.id.tvRapport);
        btnValider = (Button) findViewById(R.id.btnValider);

        Bundle paquet = this.getIntent().getExtras();

        nomVisiteur = paquet.getString("nom");
        String stringVisiteur = nomVisiteur.toString();

        mois = paquet.getInt("mois");
        stringMois = mois.toString();
        //stringMois = paquet.getString("mois");
        //mois = Integer.parseInt(stringMois);
        //tvMois.setText(StringMois);

        annee = paquet.getInt( "annee");
        stringAnnee = annee.toString();
        //stringAnnee = paquet.getString("annee");
        //annee = Integer.parseInt(stringAnnee);
        //tvAnnee.setText(StringAnnee);

        System.out.println("Les valeurs récuperer depuis RechercheRvActivity depuis ListeRvActivity : " + stringVisiteur + " " + stringMois + " " + stringAnnee);
        System.out.println("Les valeurs récuperer depuis RechercheRvActivity depuis ListeRvActivity : " + stringVisiteur + " " + mois + " " + annee);

/*
        ItemRVAdaptateur adaptateur = new ItemRVAdaptateur();
        lvRapport.setAdapter(adaptateur);
        System.out.println("ca passe dans le setAdapter");
        lvRapport.setOnItemClickListener(this);
        System.out.println("ca passe dans le OnItemClick");
*/


        System.out.println("nous sommes avant les ecouteurs");
        String url = String.format( "http://192.168.111.128:5000/rv/%s/%s/%s" , nomVisiteur ,stringMois , stringAnnee );
        System.out.println(url);



        Response.Listener<JSONArray> ecouteurReponse = new Response.Listener<JSONArray>() {
            public void onResponse(JSONArray response) {
                try {
                    System.out.println("ca passe dans le OnResponse");
                    for (int i =0 ; i < response.length(); i++){
                        Log.i("GSB", response.getJSONObject(i).getString("VISITEUR"));
                        String matVisiteur = response.getJSONObject(i).getString("VISITEUR");
                        String nomVisiteur = response.getJSONObject(i).getString("VIS_NOM");
                        String moisRapport = response.getJSONObject(i).getString("MONTH(RAP_DATE)");
                        String anneeRapport = response.getJSONObject(i).getString("YEAR(RAP_DATE)");
                        String jourRapport = response.getJSONObject(i).getString("DAY(RAP_DATE)");
                        String bilanRapport = response.getJSONObject(i).getString("RAP_BILAN");
                        String confRapport = response.getJSONObject(i).getString("RAP_CONF");

                        String leRapportFinalJSON = matVisiteur + " " + jourRapport + "/" +moisRapport + "/" + anneeRapport;
                        String leRapportDescJSON = "Visiteur : " + matVisiteur + " " + nomVisiteur + "\n" + "Date : " +jourRapport + "/" +moisRapport + "/" + anneeRapport + "\n" + "Bilan : " + bilanRapport + "\n" + "Coefficient de confiance : " + confRapport;
                        System.out.println("Dans le OnResponse reponse valeurs à récuperer leRapportFinalJSON : " + matVisiteur + " " + nomVisiteur + " " +jourRapport + " " +  moisRapport + " " + anneeRapport );
                        System.out.println("Dans le OnResponse reponse valeurs à récuperer leRapportDescJSON : " + matVisiteur + " " + nomVisiteur + " " +jourRapport + " " +  moisRapport + " " + anneeRapport + " " + bilanRapport + " " + confRapport );


                        lesRapportsJSON.add(leRapportFinalJSON);
                        lesRapportsDescJSON.add(leRapportDescJSON);
                        System.out.println("Liste des rapport ajouter à lesRapportsJSON : " + lesRapportsJSON.get(i));
                        System.out.println("La liste entiere dans lesRapportsJSON : " + lesRapportsJSON);
                        System.out.println("Liste des rapport ajouter à lesRapportsDescJSON : " + lesRapportsDescJSON.get(i));
                        System.out.println("La liste entiere dans lesRapportsDescJSON : " + lesRapportsDescJSON);


                        String leRapportJSON = lesRapportsJSON.get(i);
                        String rvDescJson = lesRapportsDescJSON.get(i);
                        System.out.println("Dans le OnResponse leRapportJSON : " + leRapportJSON);
                        System.out.println("Dans le OnResponse rvDescJson : " + rvDescJson);

                        //tvRapport.setText(leRapportFinalJSON);
                     /*   ItemRapportAdapter adaptateur = new ItemRapportAdapter();
                        lvRapport.setAdapter(adaptateur);
                     */

                     lvRapport = (ListView) findViewById(R.id.lvRapport);
                     tvRapport = (TextView) findViewById(R.id.tvRapport);
                     ArrayAdapter<String> adapter = new ArrayAdapter<String>(ListeRvActivity.this , android.R.layout.simple_list_item_1, lesRapportsJSON);
                     lvRapport.setAdapter(adapter);
                     lvRapport.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                         @Override
                         public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                             Bundle paquet = new Bundle();
                             paquet.putString("leRapportEntier", lesRapportsDescJSON.get(i));
                             Intent intentionEnvoyer = new Intent(getApplication(), VisuRvActivity.class);
                             intentionEnvoyer.putExtras(paquet);
                             startActivity(intentionEnvoyer);
                         }
                     });



 /*                       lvRapport.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                tvRapport.setText(lesRapportsJSON.get(i));
                                for (int pos = 0; pos < lesRapportsJSON.size(); pos++){

                                    System.out.println("\n tvRapport avant la condition \n" + tvRapport );
                                    System.out.println("\n tvRapport To String avant la condition \n" + tvRapport.toString());
                                    System.out.println("\n lesRapportFinauxI avant la condition \n" + lesRapportsJSON.get(pos));
                                    String leRapportJson = tvRapport.toString();
                                    System.out.println("\n leRapportJson avant la condition \n" + leRapportJson );

                                    if (leRapportJson.equals(lesRapportsJSON.get(pos))) {

                                        System.out.println("\n leRapportFinal \n" + tvRapport );
                                        System.out.println("\n lesRapportFinauxI \n" + lesRapportsJSON.get(pos));

                                        Bundle paquet = new Bundle();
                                        paquet.putString("leRapportEntier", lesRapportsJSON.get(pos));
                                        Intent intentionEnvoyer = new Intent(getApplication(), VisuRvActivity.class);
                                        intentionEnvoyer.putExtras(paquet);
                                        startActivity(intentionEnvoyer);
                                    }
                                    else
                                        System.out.println("\n il y a un probleme \n");




                                }


                            }
                        });
*/


                    }

                }
                catch( JSONException e ){
                    Log.e("GSB", "Erreur JSON : " + e.getMessage());
                    System.out.println("Erreur JSON : ");
                }
            }
        };
        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("GSB", "Erreur HTTP : " + error.getMessage());
                System.out.println("ca passe dans ecouteur erreur");
            }
        };

        JsonArrayRequest requete = new JsonArrayRequest(Request.Method.GET, url , null, ecouteurReponse, ecouteurErreur);
        RequestQueue fileReq = Volley.newRequestQueue(this);
        fileReq.add(requete);






    }


    @Override

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

        //List<RapportVisite> lesRapportVisites = (List<RapportVisite>) ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee).get(position);


    }


    class ItemRVAdaptateur extends ArrayAdapter<RapportVisite> {

        public ItemRVAdaptateur() {
            super(ListeRvActivity.this , R.layout.activity_liste_rv, ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee));

        }


        public View getView(int position, View convertView, ViewGroup parent) {

            View vItem = View.inflate(getContext(), R.layout.activity_liste_rv,null);
            final TextView tvRapport = (TextView) vItem.findViewById(R.id.tvRapport);

            String leMotif = ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee).get(position).getLeMotif().getLibelle();
            Integer leNumRapport = ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee).get(position).getNumero();
            String leBilan = ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee).get(position).getBilan();
            leRapportEntier = ModeleGsb.getInstance().getRapportsVisites(Session.getSession().getLeVisiteur(),mois,annee).get(position).toString();


            leRapport = leNumRapport.toString() +" " + leBilan + " \n" + leMotif; //Les infos du rapport qui s'affiche dans la liste

            System.out.println("\n on est dans le getView \n");

            leRapportFinal = leRapportEntier;  //Toutes les infos du rapports qui vont etre passées dans l'autre activité
            System.out.println("\n leRapportFinal dans le getView \n " + leRapportFinal );


            lesRapportFinaux.add(leRapportFinal); //Ajout de chaque rapports dans une liste
            System.out.println("\n leRapportFinal dans la liste \n" + lesRapportFinaux.get(position) );
            System.out.println( "\n la liste des rapports \n " + lesRapportFinaux );


            tvRapport.setText(leRapport);


            //btnValider.setTag(String.valueOf(lesRapportFinaux.get(position)));
            //afichage du rapport dans chaque item du listView


            return vItem;

        }
    }


    class ItemRapportAdapter extends ArrayAdapter<String> {
        public ItemRapportAdapter() {
            super(ListeRvActivity.this, R.layout.activity_liste_rv, lesRapportsJSON);

        }


        public View getView(int position, View convertView, ViewGroup parent) {

            View vItem = View.inflate(getContext(), R.layout.activity_liste_rv, null);
            final TextView tvRapport = (TextView) vItem.findViewById(R.id.tvRapport);

            String leRapport = lesRapportsJSON.get(position);
            System.out.println("leRapport normal dans le getView : " + leRapport);
            String leRvJson = lesRapportsDescJSON.get(position);
            System.out.println("leRapport desc json dans le getView : " + leRvJson);

            tvRapport.setText(leRapport);
            tvRapport.setTag(String.valueOf(position));
            System.out.println("tvRapport valueOf : " + tvRapport);

            btnValider.setTag(String.valueOf(position));



            return vItem;

        }

    }






























    //LE BOUTON A VOIR POUR PLUS TARD



    public void voir(View view) {


        for (int pos = 0; pos < lesRapportsJSON.size(); pos++){



            System.out.println("\n tvRapport To String avant la condition \n" + tvRapport.toString());
            System.out.println("\n lesRapportsJSON avant la condition : " + lesRapportsJSON.get(pos));
            String essai = tvRapport.getText().toString();
            System.out.println("\n essai avant la condition : " + essai);
            String leRapport = (String) tvRapport.getText();
            String.valueOf(tvRapport.getText().toString());
            System.out.println("\n tvRapport avant la condition \n" + tvRapport);

            if(tvRapport.getText() == lesRapportsJSON.get(pos)){

                System.out.println( leRapport+ "   <---- leRapport dans le if");
            }
            else {
                System.out.println(leRapport + "   <---- leRapport dans le else");
            }



            Bundle paquet = new Bundle();
            paquet.putString("leRapportEntier", lesRapportsDescJSON.get(pos));
            Intent intentionEnvoyer = new Intent(getApplication(), VisuRvActivity.class);
            intentionEnvoyer.putExtras(paquet);
            startActivity(intentionEnvoyer);



/*            if (leRapportJson.equals(lesRapportsJSON.get(pos))) {

                System.out.println("\n leRapportFinal \n" + tvRapport );
                System.out.println("\n lesRapportFinauxI \n" + lesRapportsJSON.get(pos));

                Bundle paquet = new Bundle();
                paquet.putString("leRapportEntier", lesRapportsJSON.get(pos));
                Intent intentionEnvoyer = new Intent(getApplication(), VisuRvActivity.class);
                intentionEnvoyer.putExtras(paquet);
                startActivity(intentionEnvoyer);
            }
            else
                System.out.println("\n il y a un probleme \n");

*/


        }









        //POUR LE MODELE

/*        for (int i = 0; i < lesRapportFinaux.size(); i++) {

            System.out.println("\n leRapportFinal avant la condition \n" + leRapportFinal);
            System.out.println("\n lesRapportFinauxI avant la condition \n" + lesRapportFinaux.get(i));

            if (leRapportFinal.equals(lesRapportFinaux.get(i))) {

                System.out.println("\n leRapportFinal \n" + leRapportFinal);
                System.out.println("\n lesRapportFinauxI \n" + lesRapportFinaux.get(i));


                Bundle paquet = new Bundle();
                paquet.putString("leRapportEntier", lesRapportFinaux.get(i));
                Intent intentionEnvoyer = new Intent(getApplication(), VisuRvActivity.class);
                intentionEnvoyer.putExtras(paquet);
                startActivity(intentionEnvoyer);


            } else
                System.out.println("\n il y a un probleme \n");

        }
        */
    }

}
