package fr.berufood.gsb_rv_visiteur;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class VisuRvActivity extends AppCompatActivity {

    TextView tvLeRapport;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visu_rv);


        tvLeRapport = (TextView) findViewById(R.id.tvLeRapport);

        Bundle paquet = this.getIntent().getExtras();
        String leRapportEntier = paquet.getString("leRapportEntier");
        tvLeRapport.setText(leRapportEntier);



















    }
}
