package fr.berufood.gsb_rv_visiteur;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by bbpow on 17/04/2018.
 */

public class ItemRapportAdaptateur extends ArrayAdapter<String> {

    List<String> lesRapports;
    Context contexte;
    int ressource;

    public ItemRapportAdaptateur(Context contexte , int ressource, List<String> lesRapports){
        super(contexte,ressource,lesRapports);
        this.contexte = contexte;
        this.ressource = ressource;
        this.lesRapports = lesRapports;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = ((Activity) contexte).getLayoutInflater();
        View vue = inflater.inflate(ressource, parent, false);
        View vItem = super.getView(position, convertView, parent);

        String element = lesRapports.get(position);
        System.out.println(lesRapports.get(position));
        TextView tvRapport = (TextView) vue.findViewById(R.id.tvRapport);
        tvRapport.setText(element);

        return vItem;


    }






}






