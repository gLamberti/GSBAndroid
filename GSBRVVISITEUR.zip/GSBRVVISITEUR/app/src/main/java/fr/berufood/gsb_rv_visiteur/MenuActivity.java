package fr.berufood.gsb_rv_visiteur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    TextView tvPrenomNomVisi ;
    Button boutonConsultRapport ;
    Button boutonSaisirRapport ;
    String prenomNomVisiteur;
    String matricule;
    String stringMatricule;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        TextView tvPrenomNomVisi = (TextView) findViewById(R.id.tvPrenomNomVisi);
        Bundle paquet = this.getIntent().getExtras();
        prenomNomVisiteur = paquet.getString("nom");
        String StringVisiteur = prenomNomVisiteur.toString();
        tvPrenomNomVisi.setText(prenomNomVisiteur);


        matricule = paquet.getString("matricule");
        //stringMatricule = matricule.toString();




      /*  tvPrenomNomVisi = (TextView) findViewById( R.id.tvPrenomNomVisi) ;

        Bundle paquet = this.getIntent().getExtras() ;
        String prenomNomVisi = paquet.getString("nom") ;
        tvPrenomNomVisi.setText(prenomNomVisi);

        */


        //Session.getSession().getLeVisiteur().getNom();
        //Session.getSession().getLeVisiteur().getPrenom();







    }



    public void consultRV(View vue) {

        Bundle paquet = new Bundle() ;
        paquet.putString("matricule",matricule);
        System.out.println("Dans le MenuActivity matricule : " + matricule);
        System.out.println("Dans le MenuActivity stringMatricule : " + stringMatricule);

        Intent intentionEnvoyer = new Intent(this, RechercheRvActivity.class);
        intentionEnvoyer.putExtras(paquet);
        startActivity(intentionEnvoyer);

    }


    public void saisirRV(View vue) {

        Bundle paquet = new Bundle();
        paquet.putString("matricule",matricule);

        Intent intentionEnvoyer = new Intent(this,SaisieRvActivity.class);
        intentionEnvoyer.putExtras(paquet);
        startActivity(intentionEnvoyer);

    }




}
