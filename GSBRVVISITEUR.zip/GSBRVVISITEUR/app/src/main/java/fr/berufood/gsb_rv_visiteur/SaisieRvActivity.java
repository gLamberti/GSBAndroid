package fr.berufood.gsb_rv_visiteur;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class SaisieRvActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{




    TextView tvDateVisite;
    TextView tvPraticien;
    TextView tvMotif;
    TextView tvBialn;
    TextView tvCoefConf;
    TextView tvChoixDate;
    Spinner spPraticien;
    Spinner spMotif;
    Spinner spCoef;
    EditText etBilan;
    Button btnDate;
    Button btnValider;
    Button btnAnnuler;

    Integer intCoef;









    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saisie_rv);

/*

        spPraticien = (Spinner) findViewById(R.id.spPraticien);
        spPraticien.setOnItemSelectedListener(this);
        ArrayAdapter<Praticien> aaPraticien = new ArrayAdapter<Praticien>(this , android.R.layout.simple_spinner_item, lesPraticiens ) ;
        aaPraticien.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPraticien.setAdapter(aaPraticien);


        spMotif = (Spinner) findViewById((R.id.spMotif));
        spMotif.setOnItemSelectedListener(this);
        ArrayAdapter<Motif> aaMotif = new ArrayAdapter<Motif>(this,android.R.layout.simple_spinner_item,lesMotifs);
        aaMotif.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMotif.setAdapter(aaMotif);



        spCoef = (Spinner) findViewById(R.id.spCoef);
        spCoef.setOnItemSelectedListener(this);
        ArrayAdapter<Integer> aaCoef = new ArrayAdapter<Integer>(this,android.R.layout.simple_spinner_item,lesCoefs);
        aaCoef.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCoef.setAdapter(aaCoef);


*/














    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
