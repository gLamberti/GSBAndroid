package fr.berufood.gsb_rv_visiteur;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.io.UnsupportedEncodingException;

import fr.berufood.gsb_rv_visiteur.modeles.ModeleGsb;
import fr.berufood.gsb_rv_visiteur.technique.Session;


public class RechercheRvActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String [] lesMois = {"01","02","03","04","05","06","07","08","09","10","11","12"};
    private static final String [] lesAnnees = {"2012","2013","2014","2015","2016","2017","2018","2019","2020"};

    Spinner spMois ;
    Spinner spAnnees ;
    ModeleGsb modele;
    Session session;
    Integer intMois;
    Integer intAnnee;
    String matricule;
    String nomVisiteur;
    String moisRapport;
    String anneeRapport;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recherche_rv);

        spMois = (Spinner) findViewById(R.id.spMois);
        spMois.setOnItemSelectedListener(this);

        ArrayAdapter<String> aaMois = new ArrayAdapter<String>(this , android.R.layout.simple_spinner_item, lesMois ) ;
        aaMois.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMois.setAdapter(aaMois);



        spAnnees = (Spinner) findViewById(R.id.spAnnee);
        spAnnees.setOnItemSelectedListener(this);

        ArrayAdapter<String> aaAnnees = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, lesAnnees ) ;
        aaAnnees.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spAnnees.setAdapter(aaAnnees);


        System.out.println("matricule dans le RechercheRvActivity avant le bundle : " + matricule);
        Bundle paquet = this.getIntent().getExtras();
        matricule = paquet.getString("matricule").toString();
        System.out.println("matricule dans le RechercheRvActivity après le bundle : " + matricule);








    }




    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        String mois = lesMois[i];
        String annee = lesAnnees[i];
        intMois = Integer.parseInt(mois);
        intAnnee = Integer.parseInt(annee);


    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void listerRv(View vue) throws UnsupportedEncodingException {

        //List<RapportVisite> lesRapportVisites = modele.getRapportsVisites(session.getLeVisiteur(),intMois,intAnnee);

        intMois = Integer.parseInt(spMois.getSelectedItem().toString());
        intAnnee = Integer.parseInt(""+spAnnees.getSelectedItem());


        Bundle paquet = new Bundle();
        paquet.putInt("mois",intMois);
        paquet.putInt("annee",intAnnee);
        paquet.putString("nom",matricule);
        System.out.println("Dans le bouton RechercheRvActivity valeurs à récuperer : " + matricule + " " + intAnnee + " " + intMois);
        Intent intentionEnvoyer = new Intent(this,ListeRvActivity.class);
        intentionEnvoyer.putExtras(paquet);
        startActivity(intentionEnvoyer);



/*        String stringMois = URLEncoder.encode(String.valueOf(intMois), "UTF-8");
        String stringAnnee = URLEncoder.encode(String.valueOf(intAnnee), "UTF-8");
        String stringVisiteur = URLEncoder.encode(matricule, "UTF-8");
        String url = String.format( "http://192.168.111.128:5000/rv/%s/%s/%s" , stringVisiteur ,stringMois , stringAnnee );
        System.out.println(url);

        Response.Listener<JSONArray> ecouteurReponse = new Response.Listener<JSONArray>() {


            public void onResponse(JSONArray response) {
                try {
                    System.out.println("ca passe dans lecouteur reponse");
                    for (int i =0 ; i < response.length(); i++){
                        Log.i("GSB", response.getJSONObject(i).getString("VISITEUR"));
                        nomVisiteur = response.getJSONObject(i).getString("VISITEUR");
                        moisRapport = response.getJSONObject(i).getString("MONTH(RAP_DATE)");
                        anneeRapport = response.getJSONObject(i).getString("YEAR(RAP_DATE)");




                    }
                    Bundle paquet = new Bundle() ;
                    paquet.putString("nom",nomVisiteur);
                    paquet.putString("mois",moisRapport);
                    paquet.putString("annee",anneeRapport);
                    System.out.println("Dans l'ecouteur reponse valeurs à récuperer : " + nomVisiteur + " " + moisRapport + " " + anneeRapport );
                    Intent intentionEnvoyer = new Intent(RechercheRvActivity.this,ListeRvActivity.class);
                    intentionEnvoyer.putExtras(paquet);
                    startActivity(intentionEnvoyer);



                }
                catch( JSONException e ){
                    Log.e("GSB", "Erreur JSON : " + e.getMessage());
                    System.out.println("Erreur JSON : ");
                }
            }
        };
        Response.ErrorListener ecouteurErreur = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("GSB", "Erreur HTTP : " + error.getMessage());
                System.out.println("ca passe dans ecouteur erreur");
            }
        };
        System.out.println("ca passe nul part");


        JsonArrayRequest requete = new JsonArrayRequest(Request.Method.GET, url , null, ecouteurReponse, ecouteurErreur);

        RequestQueue fileReq = Volley.newRequestQueue(this);
        fileReq.add(requete);

*/











       /*Bundle paquet = new Bundle();
        paquet.putInt("mois",intMois);
        paquet.putInt("annee",intAnnee);
        System.out.println(intAnnee + " " + intMois);
        Intent intentionEnvoyer = new Intent(this,ListeRvActivity.class);
        intentionEnvoyer.putExtras(paquet);
        startActivity(intentionEnvoyer);



        Intent intentEnvoyer = new Intent(this, ListeRvActivity.class);
        intentEnvoyer.putExtra("mois", intMois);
        intentEnvoyer.putExtra("annee",intAnnee);
        startActivity(intentEnvoyer);

        String moisChoisit = (String) spMois.getSelectedItem();
        String anneeChoisit = (String) spAnnees.getSelectedItem();

        Bundle paquet = new Bundle();
        paquet.putString("spMois",moisChoisit);
        paquet.putString("spAnnee",anneeChoisit);

        Intent intentionEnvoyer = new Intent(this, ListeRvActivity.class);
        intentionEnvoyer.putExtras(paquet);
        startActivity(intentionEnvoyer);
        */

    }



}
