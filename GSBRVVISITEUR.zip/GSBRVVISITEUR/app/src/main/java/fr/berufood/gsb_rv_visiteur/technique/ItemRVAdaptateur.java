/*package fr.berufood.gsb_rv_visiteur.technique;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import fr.berufood.gsb_rv_visiteur.ListeRvActivity;
import fr.berufood.gsb_rv_visiteur.R;
import fr.berufood.gsb_rv_visiteur.entites.RapportVisite;
import fr.berufood.gsb_rv_visiteur.entites.Visiteur;
import fr.berufood.gsb_rv_visiteur.modeles.ModeleGsb;

/**
 * Created by bbpow on 02/04/2018.
 */

/*public class ItemRVAdaptateur extends ArrayAdapter<RapportVisite> {

    public ItemRVAdaptateur(){
        super(ListeRvActivity.this , R.layout.item_rapportVisite, ModeleGsb.getInstance().getRapportsVisites(Visiteur visiteur, int mois, int annee)));
    }


    public View getView(int position, View convertView, ViewGroup parent) {

        View vItem = super.getView(position, convertView, parent);
        TextView tvRapport = (TextView) vItem.findViewById(R.id.tvRapport);



    }





}*/
